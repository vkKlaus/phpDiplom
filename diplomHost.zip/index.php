<?php 
require  $_SERVER['DOCUMENT_ROOT'] . '/views/main/index.php';
