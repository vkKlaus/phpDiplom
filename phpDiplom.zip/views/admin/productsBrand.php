<?php
$table='brands';
$title='Производители / Бренды';
require $_SERVER['DOCUMENT_ROOT'] . '/views/admin/productsInfo.php';
