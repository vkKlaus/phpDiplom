<?php
$table='category';
$title='Категории товара';
require $_SERVER['DOCUMENT_ROOT'] . '/views/admin/productsInfo.php';