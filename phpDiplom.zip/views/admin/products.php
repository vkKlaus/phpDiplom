<?php
require $_SERVER['DOCUMENT_ROOT'] . '/views/layouts/index.php';
resetFilterSession();

require  $_SERVER['DOCUMENT_ROOT'] . '/views/layouts/header.php';
?>

продукты

<?php require $_SERVER['DOCUMENT_ROOT'] . '/views/layouts/footer.php';
