</main>
<footer class="container-fluid footer text-center">
            <div>&copy;&emsp;Vladislav A. Klokol&emsp;2020</div>
        </footer>
        <!--!скрипты -->
        <script src="/js/jquery-3.4.1.min.js"></script>
        <script src="/js/popper.min.js"></script>
        <script src="/js/bootstrap.min.js"></script>

        <script src="/js/jquery.mousewheel.js"></script>
        <script src="/js/owl.carousel.min.js"></script>
        <script src="/js/script.js"></script>
</body>

</html>