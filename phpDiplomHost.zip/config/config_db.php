<?php

define('HOST', '127.0.0.1');
define('DB', 'apnea_shop');
define('USER', 'root');
define('PASS', '111');
define('CHARSET', 'utf8');
